﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class dbTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] != null && Session["Login"].ToString() == "Success")
        {
            //All good, they are logged in
        }
        else
        {
            //they have not logged in, redirect them to the login page
            Response.Redirect("default.aspx");
        }
    }

    protected void logout_click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Default.aspx");
    }

    protected void addContact_Click(object sender, EventArgs e)
    {
        //strResultTxt.Text += "Clicked <br>";
        strResultTxt.Text = "";

        PersonV2 temp = new PersonV2();
        temp.Fname = fNameTxt.Text;
        temp.Mname = mNameTxt.Text;
        temp.Lname = lNameTxt.Text;
        temp.City = cityTxt.Text;
        temp.State = stateTxt.Text;
        temp.Zip = zipTxt.Text;
        temp.Street1 = address1Txt.Text;
        temp.Street2 = address2Txt.Text;
        temp.Email = emailTxt.Text;
        temp.Phone = phoneTxt.Text;
        temp.CellPhone = cellPhoneTxt.Text;
        temp.Facebook = facebookTxt.Text;

        //temp.AddARecord();
        //temp.Feedback2 = strResultTxt.Text;
        strResultTxt.Text += temp.Feedback1;
        strResultTxt.Text += temp.Feedback2;

        strResultTxt.Text += "<h5 style='color:green'> <u>Record Results:</u></h5>" + "<b>First Name: </b>" + temp.Fname + "<br><b>Middle Name: </b>" + temp.Mname + "<br><b>Last Name: </b>" + temp.Lname + "<br><b>City: </b>" + temp.City + "<br><b>State: </b>" + temp.State + "<br><b>Zip: </b>" + temp.Zip + "<br><b>Address 1: </b>" + temp.Street1 + "<br><b>Address 2: </b>" + temp.Street2 + "<br><b>Email: </b>" + temp.Email + "<br><b>Phone: </b>" + temp.Phone + "<br><b>Cell Phone: </b>" + temp.CellPhone + "<br><b>Facebook: </b>" + temp.Facebook;

        //if no errors in validation...
        if (!temp.Feedback1.Contains("ERROR") || !temp.Feedback2.Contains("ERROR"))
        {
            temp.AddARecord();
        }

    }



    //WORKING
    protected void testDB_Click(object sender, EventArgs e)
    {
        //inititalize 

        //create connection object
        SqlConnection Conn = new SqlConnection();

        //initialize properties
        //login info
        Conn.ConnectionString = @"Server=sql.neit.edu,4500;Database=SE245_JCorreira;User Id=SE245_jcorreira;Password=001248229;";

        string strSQL = "INSERT INTO Persons (Fname, Mname, Lname, City, State, Zip, Street1, Street2, Email, Phone, CellPhone, Facebook) VALUES (@Fname, @Mname, @Lname, @City, @State, @Zip, @Street1, @Street2, @Email, @Phone, @CellPhone, @Facebook)";

        //bark command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;
        comm.Connection = Conn;

        //try to connect to server
        try
        {
            //opens connection
            Conn.Open();

            //feedback if successfully connected
            strResultTxt.Text += "SUCCESS! Connected to database <br><br>";

            //intRecs
            comm.ExecuteNonQuery();
            //strResultTxt.Text += "SUCCESS! Inserted " + intRecs + " record(s) <br>";

            //close connection
            Conn.Close();
            //strResult.Text += "Added: " + fName.Text;
        }
        catch
        {
            strResultTxt.Text += "ERROR: Failed to connect to database <br>";
        }
        finally
        {
            //runs regardless
            //not neccessary in c#
        }
    }//close AddARecord

}

