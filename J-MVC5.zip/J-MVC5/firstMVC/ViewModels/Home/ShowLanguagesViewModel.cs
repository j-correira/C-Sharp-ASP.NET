﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace firstMVC.ViewModels.Home
{
    public class ShowLanguagesViewModel
    {
        /*
        public ShowLanguagesViewModel(CultureInfo[] cultures)
        {
            CulturesList = cultures.Select(c = > new SelectListItem() { Text = c.EnglishName });
        }
        */
    }
}