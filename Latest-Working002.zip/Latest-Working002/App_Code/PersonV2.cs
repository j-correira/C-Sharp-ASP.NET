﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


public class PersonV2 : Person
    {

        public const string connstring = @"Server=sql.neit.edu,4500;Database=SE245_JCorreira;User Id=SE245_jcorreira;Password=001248229;";

    private string cellPhone;
        private string facebook;

        //holds error messages for inputs
        public string feedback = "";

        public string CellPhone
        {
            get
            {
                return cellPhone;
            }

            set
            {
                if (Validator.checkIfEmpty(value) == true)
                {
                    //check if length = 10
                    if (Validator.checkLength(value, 10) == true)
                    {
                        cellPhone = value;
                    }
                    else
                    {
                        feedback += "<p style='color: red;'>• <b>ERROR!</b> Invalid Cell Phone #</p>";

                    }
                }
                else
                {
                    feedback += "<p style='color: red;'>• <b>ERROR!</b> Did not enter Cell Phone #</p>";
                }
            }
        }

        public string Facebook
        {
            get
            {
                return facebook;
            }

            set
            {
                if (Validator.checkIfEmpty(value) == true)
                {
                    facebook = value;
                }
                else
                {
                    feedback += "<p style='color: red;'>• <b>ERROR!</b> Did not enter Facebook</p>";
                }
            }
        }


        public string Feedback2
        {
            get
            {
                return feedback;
            }
        }


        //sets all variables to "" so they cannot be null
        public PersonV2()
        {
            cellPhone = "";
            facebook = "";
            feedback = "";
        }




        public string AddARecord()
        {
            //inititalize 
            string strResult = "";

            //create connection object
            SqlConnection Conn = new SqlConnection();

            //initialize properties
            //login info
            Conn.ConnectionString = @"Server=sql.neit.edu,4500;Database=SE245_JCorreira;User Id=SE245_jcorreira;Password=001248229;";

            string strSQL = "INSERT INTO Persons (Fname, Mname, Lname, City, State, Zip, Street1, Street2, Email, Phone, CellPhone, Facebook) VALUES (@Fname, @Mname, @Lname, @City, @State, @Zip, @Street1, @Street2, @Email, @Phone, @CellPhone, @Facebook)";

            //bark command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@Fname", Fname);
            comm.Parameters.AddWithValue("@Mname", Mname);
            comm.Parameters.AddWithValue("@Lname", Lname);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip", Zip);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@CellPhone", CellPhone);
            comm.Parameters.AddWithValue("@Facebook", Facebook);




            //try to connect to server
            //try
            //{
                //opens connection
                Conn.Open();

        //feedback if successfully connected
        //strResult += "SUCCESS! Connected to database" + Environment.NewLine;
        //strResult.Text += "SUCCESS! Connected to database";

        //intRecs
        //int intRecs = comm.ExecuteNonQuery();
        comm.ExecuteNonQuery();
        //strResultTxt.Text += "SUCCESS! Inserted " + intRecs + " record(s) ";

        //close connection
        Conn.Close();
            //}
            //catch (Exception err)
            //{
                //strResult = "ERROR: Failed to connect to database " + err.Message;
            //}
            //finally
            //{
                //runs regardless
                //not neccessary in c#
            //}

            //return feedback string {strResult}
            return strResult;

        }//close AddARecord

        //searching


    public DataSet searchPersons(String FName, String LName)
    {
        //create dataset
        DataSet ds = new DataSet();

        //create command
        SqlCommand comm = new SqlCommand();

        //write sql statement
        String strSQL = "SELECT Person_ID, FName, MName, LName FROM Persons WHERE 0=0";

        //if text boxes are filled in, search for LIKE names
        if (FName.Length > 0)
        {
            strSQL += " AND FName LIKE @FName";
            comm.Parameters.AddWithValue("@FName", "%" + FName + "%");
        }

        if (LName.Length > 0)
        {
            strSQL += " AND LName LIKE @LName";
            comm.Parameters.AddWithValue("@LName", "%" + LName + "%");
        }

        //create & config DB tools
        SqlConnection conn = new SqlConnection();

        //who, what, where
        string strConn = @connstring;
        conn.ConnectionString = strConn;

        //info for command object
        comm.Connection = conn;     
        comm.CommandText = strSQL;  

        //data adapter
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = comm;    

        //retrieve data
        conn.Open();                
        da.Fill(ds, "Persons");     
        conn.Close();               

        //Return the data
        return ds;

    }// /searchPersons


    public SqlDataReader GetOnePerson(int intPerson_ID)
    {
        //create & init tools
        SqlConnection conn = new SqlConnection();
        SqlCommand comm = new SqlCommand();

        //connection string
        string strConn = @connstring;

        //sql command
        string sqlString =
       "SELECT Person_ID, LName, FName, MName, City, State, Zip, Street1, Street2, Email, Phone, CellPhone, Facebook FROM Persons WHERE Person_ID = @Person_ID;";

        //who, what, where
        conn.ConnectionString = strConn;

        //info for 1 person
        comm.Connection = conn;
        comm.CommandText = sqlString;
        comm.Parameters.AddWithValue("@Person_ID", intPerson_ID);

        conn.Open();

        //return dataset
        return comm.ExecuteReader();   //Return the dataset to be used by others (the calling form)
    }// /GetOnePerson

    public Int32 DeleteOnePerson(int intPerson_ID)
    {
        Int32 intRecords = 0;

        //Create and Initialize the DB Tools we need
        SqlConnection conn = new SqlConnection();
        SqlCommand comm = new SqlCommand();

        //My Connection String
        string strConn = @connstring;

        //My SQL command string to pull up one person's data
        string sqlString =
       "DELETE FROM Persons WHERE Person_ID = @Person_ID;";

        //Tell the connection object the who, what, where, how
        conn.ConnectionString = strConn;

        //Give the command object info it needs
        comm.Connection = conn;
        comm.CommandText = sqlString;
        comm.Parameters.AddWithValue("@Person_ID", intPerson_ID);

        //Open the DataBase Connection and Yell our SQL Command
        conn.Open();

        //Run the deletion and store the number of records effected
        intRecords = comm.ExecuteNonQuery();

        //close the connection
        conn.Close();

        return intRecords;   //Return # of records deleted

    }

    public Int32 UpdateRecord()
    {
        Int32 intRecords = 0;

        //Create SQL command string
        string strSQL = "UPDATE Persons SET Fname = @Fname, Mname = @Mname, Lname = @Lname, City = @City, State = @State, Zip = @Zip, Street1 = @Street1, Street2 = @Street2, Email = @Email, Phone = @Phone, CellPhone = @CellPhone, Facebook = @Facebook WHERE Person_ID = @Person_ID;";

        //string strSQL = "UPDATE Persons SET Fname = @Fname, Mname = @Mname, Lname = @Lname, City = @City, State = @State, Zip = @Zip, Street1 = @Street1, Street2 = @Street2, Email = @Email, Phone = @Phone, CellPhone = @CellPhone, Facebook = @Facebook WHERE Person_ID = @Person_ID;";

        // Create a connection to DB
        SqlConnection conn = new SqlConnection();

        //Create the who, what where of the DB
        string strConn = @connstring;
        conn.ConnectionString = strConn;

        // Bark out our command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;  //Commander knows what to say
        comm.Connection = conn;     //Where's the phone?  Here it is

        //Fill in the paramters (Has to be created in same sequence as they are used in SQL Statement)
        comm.Parameters.AddWithValue("@Fname", Fname);
        comm.Parameters.AddWithValue("@Mname", Mname);
        comm.Parameters.AddWithValue("@Lname", Lname);
        comm.Parameters.AddWithValue("@City", City);
        comm.Parameters.AddWithValue("@State", State);
        comm.Parameters.AddWithValue("@Zip", Zip);
        comm.Parameters.AddWithValue("@Street1", Street1);
        comm.Parameters.AddWithValue("@Street2", Street2);
        comm.Parameters.AddWithValue("@Email", Email);
        comm.Parameters.AddWithValue("@Phone", Phone);
        comm.Parameters.AddWithValue("@CellPhone", CellPhone);
        comm.Parameters.AddWithValue("@Facebook", Facebook);

        try
        {
            //Open the connection
            conn.Open();

            //Run the Update and store the number of records effected
            intRecords = comm.ExecuteNonQuery();
        }
        catch (Exception err)
        {
        }
        finally
        {
            //close the connection
            conn.Close();
        }

        return intRecords;

    }


}// close class

 